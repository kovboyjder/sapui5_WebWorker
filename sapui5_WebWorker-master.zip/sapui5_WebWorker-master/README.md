# sapui5_WebWorker

This is an example on how to use the Web Worker in a SAPUI5 application.

Feel free to copy the project and use it how you like.
