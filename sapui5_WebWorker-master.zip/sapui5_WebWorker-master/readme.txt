==== WELCOME ====

This is your copy of the UI5 Worklist Application Template.

Standalone runnable files (*.html) are located in the test-folder

This application is ready for client-side build in the SAP Web IDE and deployment to ABAP/HCP repositories

Enjoy development!